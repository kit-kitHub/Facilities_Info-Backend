package com.kitHub.Facilities_info.util.Authentication.loginAuthentication;

public enum AuthenticationResult {
    SUCCESS,
    USER_NOT_FOUND,
    INVALID_PASSWORD
}