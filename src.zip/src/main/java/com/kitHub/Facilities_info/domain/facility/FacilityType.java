package com.kitHub.Facilities_info.domain.facility;

public enum FacilityType {
    PARKING_LOT, // 주차장
    WELFARE_CENTER, // 복지센터
    MEDICAL_FACILITY, // 의료시설
    RESTROOM // 화장실
}
